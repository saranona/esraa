@extends('master1')
@section('content')
<p>{{$people->name}}</p>
<p>{{$people->username}}</p>
@stop
